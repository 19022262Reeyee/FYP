using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Integrated.Models;
using System;
using System.Data;
using System.Security.Claims;

namespace Integrated.Controllers
{
   public class AccountController : Controller
   {
       
      [Authorize]
      public IActionResult Logoff(string returnUrl = null)
      {
         HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
         if (Url.IsLocalUrl(returnUrl))
            return Redirect(returnUrl);
         return RedirectToAction("GuestView", "Account");
      }

      [AllowAnonymous]
      public IActionResult Login(string returnUrl = null)
      {
         TempData["ReturnUrl"] = returnUrl;
         return View();
      }

      [AllowAnonymous]
      [HttpPost]
      public IActionResult Login(UserLogin user)
      {
         if (!AuthenticateUser(user.UserID, user.Password,
                               out ClaimsPrincipal principal))
         {
            ViewData["Message"] = "Incorrect User ID or Password";
            return View();
         }
         else
         {
            HttpContext.SignInAsync(
               CookieAuthenticationDefaults.AuthenticationScheme,
               principal);

            if (TempData["returnUrl"] != null)
            {
               string returnUrl = TempData["returnUrl"].ToString();
               if (Url.IsLocalUrl(returnUrl))
                  return Redirect(returnUrl);
            }

            return RedirectToAction("Products", "Product");
         }
      }

      private bool AuthenticateUser(string uid, string pw,
                                    out ClaimsPrincipal principal)
      {
         principal = null;

         string sql = @"SELECT * FROM CustUser WHERE UserId = '{0}' AND UserPw = HASHBYTES('SHA1', '{1}')";

         string select = String.Format(sql, uid, pw);
         DataTable ds = DBUtl.GetTable(select);
         if (ds.Rows.Count == 1)
         {
                principal =
                   new ClaimsPrincipal(
                      new ClaimsIdentity(
                         new Claim[] {
                        new Claim(ClaimTypes.NameIdentifier, uid),
                        new Claim(ClaimTypes.Name, ds.Rows[0]["UserId"].ToString()),
                        new Claim(ClaimTypes.Role, ds.Rows[0]["UserId"].ToString())

                         }, 
    
                         CookieAuthenticationDefaults.AuthenticationScheme)); ;
            return true;
         }
         return false;
      }

        public IActionResult GuestView()
        {
            string check2 = $"SELECT Id, ProdName, Qty, Description, PromoPicture, Picture, Category, PromoId, PromoDiscount, Price FROM Promotions, Products WHERE PromoStartDate = Convert(date, getdate())";
            DataTable hello = DBUtl.GetTable(check2);
            if (hello.Rows.Count > 0)
            {
                hello.Columns.Add("DiscPrice", typeof(Double));
                foreach (DataRow row in hello.Rows)
                {
                    row.SetField("DiscPrice", (double)row["Price"] - ((double)row["Price"] * ((double)row["PromoDiscount"] / 100)));
                }
                return View(hello.Rows);
            }
            else
            { //returns all promotions
                string sql = "SELECT * FROM Products, Promotions ";
                DataTable dt = DBUtl.GetTable(sql);
                return View(dt.Rows);
            }
        }

        public IActionResult GuestViewInfo(string id)
        {
            string check2 = $"SELECT Id, ProdName, Qty, Description, PromoPicture, Picture, Picture_2, Picture_3, Category, PromoId, PromoDiscount, Price FROM Promotions, Products WHERE PromoStartDate = Convert(date, getdate()) AND Id={id}";
            DataTable hello = DBUtl.GetTable(check2);
            if (hello.Rows.Count > 0)
            {
                //string ProdDisc = $"SELECT Id, ProdName, Qty, Description, PromoPicture, Picture, Category, Price*{NewDisc} /100 AS [Price] FROM Products,Promotions";
                hello.Columns.Add("DiscPrice");
                foreach (DataRow row in hello.Rows)
                {
                    row.SetField("DiscPrice", (double)row["Price"] - ((double)row["Price"] * ((double)row["PromoDiscount"] / 100)));
                }
                return View(hello.Rows);
            }
            else
            { //returns all promotions
                string sql = "SELECT * FROM Products WHERE Id={0} ";
                DataTable dt = DBUtl.GetTable(sql, id);
                return View(dt.Rows);
            }
        }

    }
}