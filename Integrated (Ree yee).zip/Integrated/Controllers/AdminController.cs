﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using Integrated.Models;
using Microsoft.AspNetCore.Http;


namespace MirrahTask.Controllers
{
    public class AdminController : Controller
    {

        public IActionResult Index()
        {
            string sql = "SELECT * FROM Promotions";
            DataTable dt = DBUtl.GetTable(sql);

            return View(dt.Rows);
        }
        public IActionResult AOrder_Details()
        {
            string sql = $"SELECT i.TransactionId, t.UserId, TimeStamp, CONVERT(DATE, DATEADD(day, 14, TimeStamp)) AS [From], CONVERT(DATE, DATEADD(day, 21, TimeStamp)) AS [To], i.Id, t.PaymentMethod, p.Price, p.Picture, p.ProdName, t.Status, t.Address, t.UnitNumber, t.PostalCode FROM TransactionItems i INNER JOIN Transactions t ON i.TransactionId=t.TransactionId INNER JOIN Products p ON i.Id=p.Id WHERE (SELECT  COUNT(*) FROM    TransactionItems  f WHERE f.TransactionId = i.TransactionId AND f.TransacItemId >= i.TransacItemId) <= 1 AND Status != 'Order Received' ORDER BY TimeStamp DESC";
            DataTable dt = DBUtl.GetTable(sql);
            return View(dt.Rows);
        }

        public IActionResult StatusEdit(string id)
        {

            string sql = String.Format("SELECT* FROM Transactions WHERE TransactionId='{0}'", id);
            string select = String.Format(sql);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {

                OrderDetails Order = new OrderDetails
                {
                    TransactionId = dt.Rows[0]["TransactionId"].ToString(),

                    Status = dt.Rows[0]["Status"].ToString()
                };
                return View(Order);
            }
            else
            {
                TempData["Message"] = "Customer Not Found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("AOrder_Details");
            }
        }

        public IActionResult StatusEditPost()
        {
            IFormCollection form = HttpContext.Request.Form;
            string status = form["status"].ToString().Trim();
            string id = form["transacid"].ToString().Trim();


            string sql = @"UPDATE Transactions
SET Status = '{1}'
WHERE TransactionId='{0}'";

            string update = String.Format(sql, id, status);
            int res = DBUtl.ExecSQL(update);
            if (res == 1)
            {
                TempData["Message"] = "Customer Updated";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("AOrder_details");
        }
    }
}
