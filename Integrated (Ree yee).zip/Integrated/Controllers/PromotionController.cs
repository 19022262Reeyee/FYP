﻿using System;
using Integrated.Models;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using System.Globalization;
using System.Security.Claims;

namespace Integrated.Controllers
{
    public class PromotionController : Controller
    {
        private IWebHostEnvironment _env;
        public PromotionController(IWebHostEnvironment enviroment)
        {
            _env = enviroment;
        }
        private string DoPhotoUpload(IFormFile promopic)
        {
            string fext = Path.GetExtension(promopic.FileName);
            string uname = Guid.NewGuid().ToString();
            string filename = uname + fext;
            string fullpath = Path.Combine(_env.WebRootPath, "Images/" + filename);
            FileStream fs = new FileStream(fullpath, FileMode.Create);
            promopic.CopyTo(fs);
            fs.Close();
            return filename;

        }
        public IActionResult Promotions()
        {
            string sql = "SELECT * FROM Promotions";
            DataTable dt = DBUtl.GetTable(sql);
            GmailUtl.Authenticate();

            return View(dt.Rows);
        }

        public IActionResult AddPromo()
        {
            return View();
        }

        public IActionResult AddPromoPost(IFormFile promopic)
        {
            IFormCollection form = HttpContext.Request.Form;
            //string promoid = form["promoid"].ToString().Trim();
            string promoname = form["promoname"].ToString().Trim();
            string promodetails = form["promodetails"].ToString().Trim();
            string promocompany = form["promocompany"].ToString().Trim();
            string startdate = form["promostartdate"].ToString().Trim();
            string promoduration = form["promoduration"].ToString().Trim();
            string picfname = DoPhotoUpload(promopic);
            string promodisc = form["promodisc"].ToString().Trim();

            if (ValidUtl.CheckIfEmpty(promoname, promodetails, promocompany, promoduration, picfname, promodisc))
            {
                ViewData["Message"] = "Please enter all fields";
                ViewData["MsgType"] = "warning";
                return View("AddPromo");
            }

            if (picfname == null)
            {
                ViewData["Message"] = "Please upload a reference photo";
                ViewData["MsgType"] = "warning";
                return View("AddPromo");
            }

            string sql =
               @"INSERT INTO Promotions(PromoName, PromoDetails, PromoCompany, PromoStartDate, PromoDuration, PromoPicture, PromoDiscount)
              VALUES('{0}','{1}','{2}','{3}',{4}, '{5}', {6})";

            string insert = String.Format(sql, promoname, promodetails, promocompany, startdate, promoduration, picfname, promodisc);

            int count = DBUtl.ExecSQL(insert);
            if (count == 1)
            {
                TempData["Message"] = "Promotion Successfully Added.";
                TempData["MsgType"] = "success";
                // assistant
                // Database -> GmailUtl.SendEmail(GmailUtl.HostEmail, User.FindFirst("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress").Value, "subject", "Booking Accepted");
                // admin 
               GmailUtl.SendEmail("h0r33y33@gmail.com", "reeyeeh0@gmail.com", promoname, promodetails);
                return RedirectToAction("Promotions");
            }
            else
            {
                ViewData["Message"] = DBUtl.DB_Message;
                ViewData["MsgType"] = "danger";
                return View("AddPromo");
            }

        }


        public IActionResult DeletePromo(string id)
        {
            string delete = "DELETE FROM Promotions WHERE PromoId={0}";
            int res = DBUtl.ExecSQL(delete, id);
            if (res == 1)
            {
                TempData["Message"] = "Promotion Deleted";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("Promotions");
        }

        public IActionResult Promo(string Id)
        {
            //IFormCollection form = HttpContext.Request.Form;
            //string PromoId = form["promoid"].ToString().Trim();

            if (Id == null)
                return RedirectToAction("Promotions");
            string sql = String.Format("SELECT * FROM Promotions WHERE PromoId={0}", Id);
            string select = String.Format(sql, Id);
            DataTable dt = DBUtl.GetTable(sql);

            if (dt.Rows.Count == 1)
            {
                Promo newPromo = new Promo
                {
                    PromoId = (int)dt.Rows[0]["PromoId"],
                    PromoName = dt.Rows[0]["PromoName"].ToString(),
                    PromoDetails = dt.Rows[0]["PromoDetails"].ToString(),
                    PromoCompany = dt.Rows[0]["PromoCompany"].ToString(),
                    PromoStartDate = (DateTime)dt.Rows[0]["PromoStartDate"],
                    PromoDuration = dt.Rows[0]["PromoDuration"].ToString(),
                    PromoPicture = dt.Rows[0]["PromoPicture"].ToString(),
                    PromoDiscount = (float)(double)dt.Rows[0]["PromoDiscount"]
                };
                return View(newPromo);
            }
            else
            {
                TempData["Message"] = "Promotion Not Found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("Promotions");
            }
        }

        public IActionResult EditPromo(string Id)
        {
            //IFormCollection form = HttpContext.Request.Form;
            //string PromoId = form["promoid"].ToString().Trim();

            if (Id == null)
                return RedirectToAction("Promotions");
            string sql = String.Format("SELECT * FROM Promotions WHERE PromoId={0}", Id);
            string select = String.Format(sql, Id);
            DataTable dt = DBUtl.GetTable(sql);

            if (dt.Rows.Count == 1)
            {
                Promo newPromo = new Promo
                {
                    PromoId = (int)dt.Rows[0]["PromoId"],
                    PromoName = dt.Rows[0]["PromoName"].ToString(),
                    PromoDetails = dt.Rows[0]["PromoDetails"].ToString(),
                    PromoCompany = dt.Rows[0]["PromoCompany"].ToString(),
                    PromoStartDate = (DateTime)dt.Rows[0]["PromoStartDate"],
                    PromoDuration = dt.Rows[0]["PromoDuration"].ToString(),
                    PromoPicture = dt.Rows[0]["PromoPicture"].ToString(),
                    PromoDiscount = (float)(double)dt.Rows[0]["PromoDiscount"]
                };
                return View(newPromo);
            }
            else
            {
                TempData["Message"] = "Promotion Not Found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("Promotions");
            }
        }

        public IActionResult EditPromoPost(IFormFile promopic)
        {
            IFormCollection form = HttpContext.Request.Form;
            string Pid = form["promoid"].ToString().Trim();
            string PName = form["promoname"].ToString().Trim();
            string PDetails = form["promodetails"].ToString().Trim();
            string PCompany = form["promocompany"].ToString().Trim();
            string PSD = form["promostartdate"].ToString().Trim();
            string PDuration = form["promoduration"].ToString().Trim();
            _ = PSD + PDuration;
            string PPic = promopic == null ? form["promopicId"].ToString().Trim() : DoPhotoUpload(promopic);
            string PDisc = form["promodisc"].ToString().Trim();



            string sql = @"UPDATE Promotions

                           SET PromoName = '{1}',
                               PromoDetails   = '{2}',
                               PromoCompany = '{3}',PromoStartDate = '{4}',PromoDuration = {5}, PromoPicture = '{6}', PromoDiscount= {7}
                                     WHERE PromoId = {0}";

            string update = String.Format(sql, Pid, PName, PDetails, PCompany, PSD, PDuration, PPic, PDisc);

            int res = DBUtl.ExecSQL(update);
            if (res == 1)
            {
                TempData["Message"] = "Promotion Information Updated Successfully!";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("Promotions");
        }

        public IActionResult Uploadfile()
        {
            return View();
        }

        public IActionResult UploadFilePost(IFormFile promopic)
        {
            if (promopic == null)
            {
                ViewData["Message"] = "Please select reference picture to upload";
                ViewData["MsgType"] = "Warning";
                return View("UploadfilePost");
            }
            string filename = DoPhotoUpload(promopic);
            ViewData["promopic"] = filename;
            ViewData["Message"] = "Please select reference picture to upload";
            ViewData["MsgType"] = "Warning";
            return View("UploadfilePost");
        }

        /*public IActionResult AddDiscount()
        {
            string sql = @"UPDATE Products

                           SET Price= (SELECT Price *Promotions.PromoDiscount) 
                            WHERE PromoId={0}";

            string update = String.Format(sql, );

            int res = DBUtl.ExecSQL(update);
            if (res == 1)
            {
                TempData["Message"] = "Discount Added Successfully!";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("Promotions");
        }*/

    } //
}