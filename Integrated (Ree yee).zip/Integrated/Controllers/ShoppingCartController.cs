﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Integrated.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Security.Claims;

namespace Integrated.Controllers
{
   
    public class ShoppingCartController : Controller
    {
        private void PopulateViewData()
        {
            DataTable dt1 = DBUtl.GetTable("SELECT * FROM CustUser");
            ViewData["CustUser"] = dt1.Rows;

            DataTable dt2 = DBUtl.GetTable("SELECT * FROM AdminUser");
            ViewData["AdminUser"] = dt2.Rows;

            DataTable dt3 = DBUtl.GetTable("SELECT * FROM Promotions ");
            ViewData["Promotions"] = dt3.Rows;

            DataTable dt4 = DBUtl.GetTable("SELECT * FROM Products");
            ViewData["Products"] = dt4.Rows;

            DataTable dt5 = DBUtl.GetTable("SELECT * FROM ShoppingCart");
            ViewData["ShoppingCart"] = dt5.Rows;

            DataTable dt6 = DBUtl.GetTable("SELECT * FROM ShoppingCart2");
            ViewData["ShoppingCart2"] = dt6.Rows;

            DataTable total = DBUtl.GetTable(@"SELECT SUM(Price) AS [Total] FROM ShoppingCart2");
            ViewData["ShoppingCart2"] = total;


        }
        public IActionResult PriceTotal(String id)
        {
            string sql = "SELECT * FROM ShoppingCart WHERE UserId = 'john'";
            string select = String.Format(sql, id);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {
                Cart newcart = new Cart
                {
                    Price = (int)dt.Rows[0]["Price"],
                    Total = (int)dt.Rows[0]["SUM(Price)"]
                };
                return View(newcart);
            }

            else
            {
                TempData["Message"] = "Products not found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("Cart2");
            }
        }
       
        public IActionResult Cart()
        {

            string sql = $"SELECT p.ProdName, p.Price, p.Picture, promo.PromoDiscount, promo.PromoStartDate, s.CartId FROM Promotions promo, ShoppingCart2 s INNER JOIN Products p ON s.Id = p.Id WHERE s.UserId = '{User.Identity.Name}' AND promo.PromoStartDate = Convert(date, getdate())";
            DataTable dt = DBUtl.GetTable(sql);
            if (dt.Rows.Count > 0)
            {
                dt.Columns.Add("DiscPrice",typeof(Double));
                foreach (DataRow row in dt.Rows)
                {
                    row.SetField("DiscPrice", (double)row["Price"] - ((double)row["Price"] * ((double)row["PromoDiscount"] / 100)));
                }
            }
            else
            {
                sql = $"SELECT p.ProdName, p.Price, p.Picture, s.CartId FROM ShoppingCart2 s INNER JOIN Products p ON s.Id = p.Id WHERE s.UserId = '{User.Identity.Name}'";
                dt = DBUtl.GetTable(sql);
            }
            return View(dt.Rows);
        }

        public IActionResult CheckOut()
        {

            string currentUserId = User.Identity.Name;
            string sql = $"SELECT p.ProdName, p.Price, p.Picture, promo.PromoDiscount, promo.PromoStartDate, s.CartId FROM Promotions promo, ShoppingCart2 s INNER JOIN Products p ON s.Id = p.Id WHERE s.UserId = '{User.Identity.Name}' AND promo.PromoStartDate = Convert(date, getdate())";
            DataTable dt = DBUtl.GetTable(sql);

            if (dt.Rows.Count > 0)
            {
                dt.Columns.Add("DiscPrice", typeof(Double));
                foreach (DataRow row in dt.Rows)
                {
                    row.SetField("DiscPrice", (double)row["Price"] - ((double)row["Price"] * ((double)row["PromoDiscount"] / 100)));
                }
            } else
            {
                sql = $"SELECT p.ProdName, p.Price, p.Picture, s.CartId FROM ShoppingCart2 s INNER JOIN Products p ON s.Id = p.Id WHERE s.UserId = '{User.Identity.Name}'";
                dt = DBUtl.GetTable(sql);
            }
            return View(dt.Rows);
        }

        public IActionResult CancelTransac()
        {
            string delete = "DELETE FROM Transactions WHERE TransactionId=(SELECT TOP 1 TransactionId FROM Transactions ORDER BY TransactionId DESC);";
            int res = DBUtl.ExecSQL(delete);
            if (res == 1)
            {
                TempData["Message"] = "Transaction Cancelled";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("CheckOut");
        }
        public IActionResult Check()
        {
            return View();
        }
        public IActionResult AddTransaction()
        {
            string currentUserId = User.Identity.Name;
            IFormCollection form = HttpContext.Request.Form;
            string name = form["name"].ToString().Trim();
            string number = form["number"].ToString().Trim();
            string addr = form["addr"].ToString().Trim();
            string unit = form["unit"].ToString().Trim();
            string postal = form["postal"].ToString().Trim();
            string PayType = form["paytype"].ToString().Trim();
            
       

            if (ValidUtl.CheckIfEmpty(name, number, addr, unit, postal, PayType))
            {
                ViewData["Message"] = "Please pick a payment option";
                ViewData["MsgType"] = "warning";
                return View("Check");
            }

          

            string sql =
               $"INSERT INTO Transactions(UserId, Name, ContactNumber, Address, UnitNumber, PostalCode, PaymentMethod) VALUES('{currentUserId}','{name}','{number}','{addr}','{unit}','{postal}','{PayType}')";

            

            int count = DBUtl.ExecSQL(sql);
            if (count == 1)
            {
                TempData["Message"] = "Make Payment";
                TempData["MsgType"] = "success";
              
                return RedirectToAction("Cart");
            }
            else
            {
                ViewData["Message"] = DBUtl.DB_Message;
                ViewData["MsgType"] = "danger";
                return View("CheckOut");
            }

        }
  
        public IActionResult CartDelete(String id)
        {
            string sql = "DELETE FROM ShoppingCart2 WHERE CartId={0}";
            string delete = String.Format(sql, id);
            int res = DBUtl.ExecSQL(delete);
            if (res == 1)
            {
                TempData["Message"] = "Product Deleted";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("Cart");
        }

        public IActionResult CheckOutDelete(String id)
        {
            string sql = "DELETE FROM ShoppingCart2 WHERE CartId={0}";
            string delete = String.Format(sql, id);
            int res = DBUtl.ExecSQL(delete);
            if (res == 1)
            {
                TempData["Message"] = "Product Deleted";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("CheckOut");
        }

        public IActionResult payment()
        {
            return View();
        }

        public IActionResult Oncancel()
        {
            return View();
        }

        public IActionResult success()
        {
            return View();
        }


    }
}
