﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Integrated.Controllers
{
    public class PayPalController : Controller
    {
        public IActionResult payment()
        {
            return View();
        }

        public IActionResult Oncancel()
        {
            return View();
        }

        public IActionResult success()
        {
            string currentUserId = User.Identity.Name;
            string sql = $"SELECT i.TransactionId, i.Id, t.PaymentMethod, i.Price, p.Picture, p.ProdName, t.Status FROM TransactionItems i INNER JOIN Transactions t ON i.TransactionId=t.TransactionId INNER JOIN Products p ON i.Id=p.Id WHERE i.TransactionId=(SELECT TOP 1 TransactionId FROM Transactions ORDER BY TimeStamp DESC) AND t.UserId='{currentUserId}'";
            DataTable dt = DBUtl.GetTable(sql);
            return View(dt.Rows);
        }

        public IActionResult CartCollect()

        {

            string currentUserId = User.Identity.Name;
            string sqlDiscount = "SELECT promo.PromoDiscount FROM Promotions promo WHERE promo.PromoStartDate = Convert(date, getdate());";

            DataTable discounts = DBUtl.GetTable(sqlDiscount);
            int discount = 0;

            if (discounts.Rows.Count > 0)
            {
                discount = (int)(double) discounts.Rows[0]["PromoDiscount"];
            }

            string collect = $"INSERT INTO TransactionItems(TransactionId, Id, Price) SELECT TransactionId, cart.Id, prod.Price - (prod.Price * {discount}/100) FROM Transactions, ShoppingCart2 cart INNER JOIN Products prod ON cart.Id=prod.Id WHERE TransactionId=(SELECT TOP 1 TransactionId FROM Transactions ORDER BY TimeStamp DESC) AND cart.UserId='{currentUserId}'; DELETE FROM ShoppingCart2 WHERE UserId='{currentUserId}'";
            string delshopcart = $"DELETE FROM ShoppingCart2 WHERE UserId='{currentUserId}'";
            
            string insert = String.Format(collect);

            int count = DBUtl.ExecSQL(insert);
            if (count == 1)
            {
                _ = DBUtl.ExecSQL(delshopcart);
               
                    TempData["Message"] = "Payment Complete";
                    TempData["MsgType"] = "success";
                
                
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("success");
        }

        public IActionResult OrderDetails_View(string id)
        {
            string sql = "SELECT i.TransactionId, i.Id, t.PaymentMethod, p.Price, p.Picture, p.ProdName, t.Status FROM TransactionItems i INNER JOIN Transactions t ON i.TransactionId=t.TransactionId INNER JOIN Products p ON i.Id=p.Id WHERE i.TransactionId ='{0}'";
            DataTable dt = DBUtl.GetTable(sql, id);
            return View(dt.Rows);
        }

        public IActionResult CartDelete()

        {
            string currentUserId = User.Identity.Name;
            
            string delshopcart = $"DELETE FROM ShoppingCart2 WHERE UserId='{currentUserId}'";
            string delete = String.Format(delshopcart);
            int res = DBUtl.ExecSQL(delete);

            if (res == 1)
            {
                TempData["Message"] = "Payment Complete";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("success");
        }
    }
}
