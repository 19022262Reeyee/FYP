﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.IO;
using Integrated.Models;
using System.Security.Claims;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;

namespace Integrated.Controllers
{
    public class ProductController : Controller
    {


        private IWebHostEnvironment _env;

        public ProductController(IWebHostEnvironment environment)
        {
            _env = environment;
        }

        private string DoPhotoUpload(IFormFile photo)
        {
            string fext = Path.GetExtension(photo.FileName);
            string uname = Guid.NewGuid().ToString();
            string fname = uname + fext;
            string fullpath = Path.Combine(_env.WebRootPath, "images/" + fname);
            FileStream fs = new FileStream(fullpath, FileMode.Create);
            photo.CopyTo(fs);
            fs.Close();
            return fname;
        }
        public IActionResult Products()
        {
           
            string check2 = $"SELECT Id, ProdName, Qty, Description, PromoPicture, Picture, Category, PromoId, PromoDiscount, Price FROM Promotions, Products WHERE PromoStartDate = Convert(date, getdate())";
        DataTable hello = DBUtl.GetTable(check2);
            if (hello.Rows.Count > 0)
            {
            hello.Columns.Add("DiscPrice", typeof(Double));
            foreach (DataRow row in hello.Rows)
            {
                row.SetField("DiscPrice", (double)row["Price"] - ((double) row["Price"] * ((double)row["PromoDiscount"] / 100)));
            }
                return View(hello.Rows);
            }
            else
            { //returns all promotions
                string sql = "SELECT * FROM Products, Promotions ";
                DataTable dt = DBUtl.GetTable(sql);
                return View(dt.Rows);
            }
    
        }

        public IActionResult Info(string id)
        {
            string check2 = $"SELECT Id, ProdName, Qty, Description, PromoPicture, Picture, Picture_2, Picture_3, Category, PromoId, PromoDiscount, Price FROM Promotions, Products WHERE PromoStartDate = Convert(date, getdate()) AND Id={id}";
            DataTable hello = DBUtl.GetTable(check2);
            
            if (hello.Rows.Count > 0)
            {
                hello.Columns.Add("DiscPrice", typeof(Double));
                foreach (DataRow row in hello.Rows)
                {
                    row.SetField("DiscPrice", (double)row["Price"] - ((double)row["Price"] * ((double)row["PromoDiscount"] / 100)));
                }
                return View(hello.Rows);
            }
            else
            { //returns all promotions
                string sql = "SELECT * FROM Products WHERE Id={0} ";
                DataTable dt = DBUtl.GetTable(sql, id);
                return View(dt.Rows);
            }
        }

        public IActionResult AddToCart(String id)
        {
            string currentUserId = User.Identity.Name;
            string sql = $"INSERT INTO ShoppingCart2(Id, UserId) SELECT Id, UserId FROM Products, CustUser WHERE Id='{id}' AND UserId ='{currentUserId}'";



                string add = String.Format(sql, id);
                int res = DBUtl.ExecSQL(add);
                if (res == 1)
                {
                    TempData["Message"] = "Added to Cart";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
              
            return RedirectToAction("Products");
        }
        public IActionResult MyCart()
        {

            string userid = User.Identity.Name;
            string select = @"SELECT * FROM ShoppingCart 
                                          WHERE UserId ='{0}'";
            List<UserLogin> list = DBUtl.GetList<UserLogin>(select, userid);
            return View("MyCart", list);
        }
        public IActionResult AddToCart2(String id)
        {

            string sql1 = "SELECT * FROM CustUser";
           // string select = String.Format(sql1, id);
            DataTable dt = DBUtl.GetTable(sql1);
            UserLogin user = new UserLogin
            {
                UserID = dt.Rows[0]["UserId"].ToString(),
                Password = dt.Rows[0]["UserPw"].ToString()
            };

        string userid = "john";
            
            string sql2= @"INSERT INTO Shopping Cart(Id, ProdName, Qty, Price, Description, Picture, Category)
                         SELECT (Id, ProdName, Qty, Price, Description, Picture, Category) FROM Products WHERE Id={0}";
            string sql =
              @"INSERT INTO ShoppingCart(UserId)
              VALUES('{0}')";

                string insert = String.Format(sql2, sql, userid);

                int count = DBUtl.ExecSQL(insert);

                if (count == 1)
                {
                    TempData["Message"] = "Added to Cart";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }// }
            return RedirectToAction("Products");
        }
       
        public IActionResult ProdDelete(String id)
        {
            string sql = "DELETE FROM Products WHERE Id={0}";
            string delete = String.Format(sql, id);
            int res = DBUtl.ExecSQL(delete);
            if (res == 1)
            {
                TempData["Message"] = "Product Deleted";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("Products");
        }
        public IActionResult Plushies()
        {
            string check2 = $"SELECT Id, ProdName, Qty, Description, PromoPicture, Picture, Category, PromoId, PromoDiscount, Price FROM Promotions, Products WHERE PromoStartDate = Convert(date, getdate()) AND Category = 'Plushies'";
            DataTable hello = DBUtl.GetTable(check2);
            if (hello.Rows.Count > 0)
            {
                //string ProdDisc = $"SELECT Id, ProdName, Qty, Description, PromoPicture, Picture, Category, Price*{NewDisc} /100 AS [Price] FROM Products,Promotions";

                hello.Columns.Add("DiscPrice", typeof(Double));
                foreach (DataRow row in hello.Rows)
                {
                    row.SetField("DiscPrice", (double)row["Price"] - ((double)row["Price"] * ((double)row["PromoDiscount"] / 100)));
                }
                return View(hello.Rows);
            }
            else
            { //returns all promotions
                string sql = "SELECT * FROM Products WHERE Category = 'Plushies'";
                DataTable dt = DBUtl.GetTable(sql);
                return View(dt.Rows);
            }
        }

        public IActionResult Bottles()
        {
            string check2 = $"SELECT Id, ProdName, Qty, Description, PromoPicture, Picture, Category, PromoId, PromoDiscount, Price FROM Promotions, Products WHERE PromoStartDate = Convert(date, getdate()) AND Category = 'Bottles'";
            DataTable hello = DBUtl.GetTable(check2);
            if (hello.Rows.Count > 0)
            {
                //string ProdDisc = $"SELECT Id, ProdName, Qty, Description, PromoPicture, Picture, Category, Price*{NewDisc} /100 AS [Price] FROM Products,Promotions";

                hello.Columns.Add("DiscPrice", typeof(Double));
                foreach (DataRow row in hello.Rows)
                {
                    row.SetField("DiscPrice", (double)row["Price"] - ((double)row["Price"] * ((double)row["PromoDiscount"] / 100)));
                }
                return View(hello.Rows);
            }
            else
            { //returns all promotions
                string sql = "SELECT * FROM Products WHERE Category = 'Bottles'";
                DataTable dt = DBUtl.GetTable(sql);
                return View(dt.Rows);
            }
        }

        public IActionResult Phones()
        {
            string check2 = $"SELECT Id, ProdName, Qty, Description, PromoPicture, Picture, Category, PromoId, PromoDiscount, Price FROM Promotions, Products WHERE PromoStartDate = Convert(date, getdate()) AND Category = 'Phones'";
            DataTable hello = DBUtl.GetTable(check2);
            if (hello.Rows.Count > 0)
            {
                //string ProdDisc = $"SELECT Id, ProdName, Qty, Description, PromoPicture, Picture, Category, Price*{NewDisc} /100 AS [Price] FROM Products,Promotions";

                hello.Columns.Add("DiscPrice", typeof(Double));
                foreach (DataRow row in hello.Rows)
                {
                    row.SetField("DiscPrice", (double)row["Price"] - ((double)row["Price"] * ((double)row["PromoDiscount"] / 100)));
                }
                return View(hello.Rows);
            }
            else
            { //returns all promotions
                string sql = "SELECT * FROM Products WHERE Category = 'Phones'";
                DataTable dt = DBUtl.GetTable(sql);
                return View(dt.Rows);
            }
        }

        public IActionResult ProdAdd()
        {
            return View();
        }

        public IActionResult ProdAddPost(IFormFile picture)
        {
            IFormCollection form = HttpContext.Request.Form;

            
            string name = form["name"].ToString().Trim();
            string qty = form["qty"].ToString().Trim();
            string price = form["price"].ToString().Trim();
            string desc = form["desc"].ToString().Trim();
            string cat = form["cat"].ToString().Trim();
            string message = "";
            if (ValidUtl.CheckIfEmpty(name, desc))
            {
                message = "Please enter Title, City and Story <br/>";
            }



            if (!price.IsNumeric())
            {
                message += "Invalid Spending <br/>";
            }


            if (picture == null)
            {
                message += "Please upload a photo";
            }

            if (!message.Equals(""))
            {
                ViewData["Message"] = message;
                ViewData["MsgType"] = "warning";
                return View("ProdAdd");
            }

            string fname = DoPhotoUpload(picture);
            ViewData["Picture"] = fname;
            ViewData["Message"] = "Picture successfully uploaded";
            ViewData["MsgType"] = "success";

            string sql =
              @"INSERT INTO Products(ProdName, Qty, Price, Description, Picture, Category)
              VALUES('{0}', {1}, {2}, '{3}', '{4}', '{5}')";

            string insert = String.Format(sql, name, qty, price, desc, picture, cat);

            int count = DBUtl.ExecSQL(insert);

            if (count == 1)
            {
                TempData["Message"] = "Product Successfully Added.";
                TempData["MsgType"] = "success";
                return View("ProdAdd");
            }
            else
            {
                ViewData["Message"] = DBUtl.DB_Message;
                ViewData["MsgType"] = "danger";
                return View("ProdAdd");
            }
        }

        public IActionResult test()
        {
            return View();
        }

        public IActionResult TestAdd()
        {
            IFormCollection form = HttpContext.Request.Form;

            string userid = form["userid"].ToString().Trim();
            string id = form["id"].ToString().Trim();
            string prodname = form["prodname"].ToString().Trim();
            string qty = form["qty"].ToString().Trim();
            string price = form["price"].ToString().Trim();
            string desc = form["desc"].ToString().Trim();
            string picture = form["picture"].ToString().Trim();
            string category = form["category"].ToString().Trim();

            string sql =
              @"INSERT INTO ShoppingCart(UserId, Id, ProdName, Qty, Price, Description, Picture, Category)
              VALUES('{0}', {1}, '{2}', {3}, {4}, '{5}', '{6}', '{7}')";

            string insert = String.Format(sql, userid, id, prodname, qty, price, desc, picture, category);

            int count = DBUtl.ExecSQL(insert);

            if (count == 1)
            {
                TempData["Message"] = "Product Successfully Added.";
                TempData["MsgType"] = "success";
                return View("test");
            }
            else
            {
                ViewData["Message"] = DBUtl.DB_Message;
                ViewData["MsgType"] = "danger";
                return View("test");
            }
        }
    }
}
