﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Integrated.Models;


namespace Integrated.Controllers
{
    public class CustomerController : Controller
    {
       public IActionResult CustAdd()
        {
            return View();
        }

        public IActionResult CustAddPost()
        {
            IFormCollection form = HttpContext.Request.Form;
            string username = form["username"].ToString().Trim();
            string password = form["password"].ToString().Trim();
            string custname = form["custname"].ToString().Trim();

            if (ValidUtl.CheckIfEmpty(username, password, custname))
            {
                ViewData["Message"] = "Please enter all fields";
                ViewData["MsgType"] = "warning";
                return View("CustAdd");
            }

            string sql =
               @"INSERT INTO CustUser (UserId, UserPw, FullName)
              VALUES('{0}',HASHBYTES('SHA1', '{1}'),'{2}')";

            string insert = String.Format(sql, username, password, custname);

            int count = DBUtl.ExecSQL(insert);
            if (count == 1)
            {
                TempData["Message"] = "Customer Successfully Signed Up.";
                TempData["MsgType"] = "success";
                return RedirectToAction("Login", "Account");
            }
            else
            {
                ViewData["Message"] = DBUtl.DB_Message;
                ViewData["MsgType"] = "danger";
                return RedirectToAction("Login", "Account");
            }
        }

        public IActionResult OrderDetails()
        {
            string currentUserId = User.Identity.Name;
            string sql = $"SELECT * FROM Transactions WHERE UserId='{currentUserId}' ORDER BY TimeStamp DESC";
            DataTable dt = DBUtl.GetTable(sql);
            return View(dt.Rows);
        }

        public IActionResult CustStatusEdit(string id)
        {

            string sql = @"UPDATE Transactions
SET Status = 'Order Received'
WHERE TransactionId='{0}'";

            string update = String.Format(sql, id);
            int res = DBUtl.ExecSQL(update);
            if (res == 1)
            {
                TempData["Message"] = "Order Status Updated";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("OrderDetails");
        }

        public IActionResult OrderDetails_View(string id)
        {
            string sql = "SELECT i.TransactionId, i.Id, t.PaymentMethod, i.Price, p.Picture, p.ProdName, t.Status, t.Address, t.UnitNumber, t.PostalCode FROM TransactionItems i INNER JOIN Transactions t ON i.TransactionId=t.TransactionId INNER JOIN Products p ON i.Id=p.Id WHERE i.TransactionId ='{0}'";
            DataTable dt = DBUtl.GetTable(sql, id);
            return View(dt.Rows);
        }
        public IActionResult ToShip()
        {
            string currentUserId = User.Identity.Name;
            string sql = $"SELECT i.TransactionId, TimeStamp, CONVERT(DATE, DATEADD(day, 14, TimeStamp)) AS [From], CONVERT(DATE, DATEADD(day, 21, TimeStamp)) AS [To], i.Id, t.PaymentMethod, p.Price, p.Picture, p.ProdName, t.Status, t.Address, t.UnitNumber, t.PostalCode FROM TransactionItems i INNER JOIN Transactions t ON i.TransactionId=t.TransactionId INNER JOIN Products p ON i.Id=p.Id WHERE (SELECT  COUNT(*) FROM    TransactionItems  f WHERE f.TransactionId = i.TransactionId AND f.TransacItemId >= i.TransacItemId) <= 1 AND UserId='{currentUserId}' AND Status = 'To Ship' ORDER BY TimeStamp DESC";
            DataTable dt = DBUtl.GetTable(sql);
            return View(dt.Rows);
        }

        public IActionResult OutForDelivery()
        {
            string currentUserId = User.Identity.Name;
            string sql = $"SELECT i.TransactionId, TimeStamp, CONVERT(DATE, DATEADD(day, 14, TimeStamp)) AS [From], CONVERT(DATE, DATEADD(day, 21, TimeStamp)) AS [To], i.Id, t.PaymentMethod, p.Price, p.Picture, p.ProdName, t.Status, t.Address, t.UnitNumber, t.PostalCode FROM TransactionItems i INNER JOIN Transactions t ON i.TransactionId=t.TransactionId INNER JOIN Products p ON i.Id=p.Id WHERE (SELECT  COUNT(*) FROM    TransactionItems  f WHERE f.TransactionId = i.TransactionId AND f.TransacItemId >= i.TransacItemId) <= 1 AND UserId='{currentUserId}' AND Status = 'Out For Delivery' ORDER BY TimeStamp DESC";
            DataTable dt = DBUtl.GetTable(sql);
            return View(dt.Rows);
        }

        public IActionResult ToBeReceived()
        {
            string currentUserId = User.Identity.Name;
            string sql = $"SELECT i.TransactionId, TimeStamp, CONVERT(DATE, DATEADD(day, 14, TimeStamp)) AS [From], CONVERT(DATE, DATEADD(day, 21, TimeStamp)) AS [To], i.Id, t.PaymentMethod, p.Price, p.Picture, p.ProdName, t.Status, t.Address, t.UnitNumber, t.PostalCode FROM TransactionItems i INNER JOIN Transactions t ON i.TransactionId=t.TransactionId INNER JOIN Products p ON i.Id=p.Id WHERE (SELECT  COUNT(*) FROM    TransactionItems  f WHERE f.TransactionId = i.TransactionId AND f.TransacItemId >= i.TransacItemId) <= 1 AND UserId='{currentUserId}' AND Status = 'To Be Received' ORDER BY TimeStamp DESC";
            DataTable dt = DBUtl.GetTable(sql);
            return View(dt.Rows);
        }

        public IActionResult CompletedOrders()
        {
            string currentUserId = User.Identity.Name;
            string sql = $"SELECT i.TransactionId, TimeStamp, CONVERT(DATE, DATEADD(day, 14, TimeStamp)) AS [From], CONVERT(DATE, DATEADD(day, 21, TimeStamp)) AS [To], i.Id, t.PaymentMethod, p.Price, p.Picture, p.ProdName, t.Status, t.Address, t.UnitNumber, t.PostalCode FROM TransactionItems i INNER JOIN Transactions t ON i.TransactionId=t.TransactionId INNER JOIN Products p ON i.Id=p.Id WHERE (SELECT  COUNT(*) FROM    TransactionItems  f WHERE f.TransactionId = i.TransactionId AND f.TransacItemId >= i.TransacItemId) <= 1 AND UserId='{currentUserId}' AND Status = 'Order Received' ORDER BY TimeStamp DESC";
            DataTable dt = DBUtl.GetTable(sql);
            return View(dt.Rows);
        }
    }
}
