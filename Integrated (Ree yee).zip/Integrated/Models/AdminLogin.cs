﻿
using System.ComponentModel.DataAnnotations;

namespace Integrated.Models
{
    public class AdminLogin
    {

        [Required(ErrorMessage = "Please enter Admin ID")]
        public string AdminID { get; set; }
        [Required(ErrorMessage = "Please enter Password")]
        public string Password { get; set; }
    }
}

