﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Integrated.Models
{
    public class Promo
    {
        public int PromoId { get; set; }
        public string PromoName { get; set; }
        public string PromoDetails { get; set; }
        public string PromoCompany { get; set; }
        public DateTime PromoStartDate { get; set; }
        public DateTime PromoEndDate { get; set; }
        public string PromoDuration { get; set; }
        public string PromoPicture { get; set; }

        public float PromoDiscount { get; set; }

        public string FormattedStartDate()
        {
            return PromoStartDate.ToString("yyyy-MM-dd");
        }

    }
}