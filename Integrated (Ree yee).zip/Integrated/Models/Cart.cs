﻿using Microsoft.AspNetCore.Http;
using System;
using System.ComponentModel.DataAnnotations;

namespace Integrated.Models
{
    public class Cart
    {
        public string UserId { get; set; }

        [Required(ErrorMessage = "Please enter Product Name")]
        [StringLength(100, ErrorMessage = "Max 100 chars")]
        public string ProdName { get; set; }

        [Required(ErrorMessage = "Please enter Quantity")]
        
        public int Qty { get; set; }

        [Required(ErrorMessage = "Please enter a Price")]
       
        public float Price { get; set; }

        [Required(ErrorMessage = "Please enter a Description")]
        public string Description { get; set; }

        public string Picture { get; set; }

        public string Category { get; set; }
        public int Id { get; set; }

        public int Total { get; set; }



    }
}

