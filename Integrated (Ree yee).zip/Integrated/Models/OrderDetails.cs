﻿using Microsoft.AspNetCore.Http;
using System;
using System.ComponentModel.DataAnnotations;

namespace Integrated.Models
{
    public class OrderDetails
    {
        public int OrderId { get; set; }

        public string TransactionId { get; set; }

        public string UserId { get; set; }
        public int Id { get; set; }
        public string ProdName { get; set; }

        

        public int Qty { get; set; }

        

        public float Price { get; set; }

       
        public string Description { get; set; }

        public string Picture { get; set; }

        public string Category { get; set; }

        public string Status { get; set; }

        public int Total { get; set; }



    }
}

