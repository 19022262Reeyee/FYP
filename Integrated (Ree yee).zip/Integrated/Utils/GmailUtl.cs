﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Gmail.v1;
using Google.Apis.Gmail.v1.Data;
using Google.Apis.Services;
using Google.Apis.Util.Store;
using System.IO;
using System.Threading;
using MimeKit;
using Microsoft.Extensions.Configuration;

public static class GmailUtl
{

    public static string HostEmail = "h0r33y33@gmail.com";
    public static GmailService service;

    public static void Authenticate()
    {
        UserCredential credential;
        string[] Scopes = { GmailService.Scope.MailGoogleCom };

        using (var stream =
            new FileStream("credentialdesktop.json", FileMode.Open, FileAccess.Read))
        {
            // The file token.json stores the user's access and refresh tokens, and is created
            // automatically when the authorization flow completes for the first time.
            string credPath = "token.json";
            credential = GoogleWebAuthorizationBroker.AuthorizeAsync(
                GoogleClientSecrets.Load(stream).Secrets,
                Scopes,
                "user",
                CancellationToken.None,
                new FileDataStore(credPath, true)).Result;
            Console.WriteLine("Credential file saved to: " + credPath);
        }

        // Create Gmail API service.
        service = new GmailService(new BaseClientService.Initializer()
        {
            HttpClientInitializer = credential,
            ApplicationName = "HelloWorld",
        });

        // Define parameters of request.
        UsersResource.LabelsResource.ListRequest request = service.Users.Labels.List("me");

        // List labels.
        IList<Label> labels = request.Execute().Labels;
        Console.WriteLine("Labels:");
        if (labels != null && labels.Count > 0)
        {
            foreach (var labelItem in labels)
            {
                Console.WriteLine("{0}", labelItem.Name);
            }
        }
        else
        {
            Console.WriteLine("No labels found.");
        }
    }

    public static void SendEmail(string from, string to, string subject, string message)
    {
        if (service == null)
        {
            return;
        }

        MimeMessage mimeMessage = new MimeMessage();
        BodyBuilder builder = new BodyBuilder();
        builder.TextBody = message;
        mimeMessage.To.Add(new MailboxAddress("", to));
        mimeMessage.Body = builder.ToMessageBody();
        mimeMessage.Subject = subject;
        MailboxAddress addr = new MailboxAddress(from, from);
        mimeMessage.From.Add(addr);

        MemoryStream ms = new MemoryStream();
        mimeMessage.WriteTo(ms);
        ms.Position = 0;
        StreamReader sr = new StreamReader(ms);
        Google.Apis.Gmail.v1.Data.Message msg = new Google.Apis.Gmail.v1.Data.Message();
        string rawString = sr.ReadToEnd();

        byte[] raw = System.Text.Encoding.UTF8.GetBytes(rawString);
        msg.Raw = System.Convert.ToBase64String(raw);
        var res = service.Users.Messages.Send(msg, "me").Execute();
    }
}